import firebase from 'firebase';
const firebaseConfig = {
    apiKey: "AIzaSyCJNO_56-7jmKVl665qoREh8o1sKKXXULM",
    authDomain: "maria-alejandra-front.firebaseapp.com",
    projectId: "maria-alejandra-front",
    storageBucket: "maria-alejandra-front.appspot.com",
    messagingSenderId: "229425552668",
    appId: "1:229425552668:web:9a4acfc9a0e01d268faed9"
  };
  // Initialize Firebase
firebase.initializeApp(firebaseConfig);

export {firebase}
