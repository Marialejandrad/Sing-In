import React from 'react';
import {firebase} from './firebase';
const Home=()=>{
    const signOut =()=>{
        firebase.auth().signOut();
    }
    return(
        <>
        <h1>Home</h1>
        <button onClick={signOut}>cerrar sesión</button>
        </>
    )
}
export default Home
